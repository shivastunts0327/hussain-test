package com.example.spring.mongo.api;

import java.util.List;

import org.springframework.stereotype.Service;


@Service
public interface EmployeeService {
	List<Employee> findAll();
	Employee save(Employee employee);
	List<Employee> findByFirstName(String  firstName);

}
