package com.example.spring.mongo.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;




@Controller
@RestController
@RequestMapping(value="/Employee")
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping(value="/post")
	public Employee post(@RequestBody Employee employee) {
	return employeeService.save(employee);
	}
	@GetMapping(value="/get")
	public List<Employee> getAll(){
		return employeeService.findAll();
	}
	@GetMapping(value="/{firstName}")
	public List<Employee> getname(@RequestParam String firstName){
		return employeeService.findByFirstName(firstName);
	}
	

}