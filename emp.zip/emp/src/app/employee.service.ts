import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from '@angular/common/http'
import { Observable } from 'rxjs';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  

  constructor(private httpClient:HttpClient) { }

  baseUrl = 'http://localhost:8082/Employee/get';

  getEmployee(): Observable<Employee[]> {
      return this.httpClient.get<Employee[]>(this.baseUrl);
          
  }
}
